import os, pickle, face_recognition
from PIL import Image
import io

# 📂 Carpeta con las fotos en PNG (nombre = ID.png)
INPUT_FOLDER = "fotos_png"
# 📂 Carpeta donde se guardarán los lotes PKL
OUTPUT_FOLDER = "encodings_pkl"
# 🔢 Tamaño de lote
LOTE_SIZE = 100000

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

def generar_pkls_por_lotes():
    print("Inicia lecctura de directorio ...")
    archivos = [f for f in os.listdir(INPUT_FOLDER) if f.lower().endswith(".jpg")]
    archivos.sort()  # opcional, ordenados por ID
    
    print(f"Archivos leídos: {len(archivos)}")

    lote, count, lote_idx = [], 0, 1
    
    PROCESO = "2026201"

    for archivo in archivos:
        id_foto = os.path.splitext(archivo)[0]  # quita la extensión
        path = os.path.join(INPUT_FOLDER, archivo)

        try:
            # Cargar imagen
            imagen = face_recognition.load_image_file(path)
            encodings = face_recognition.face_encodings(imagen)

            if not encodings:
                print(f"No se detectó rostro en {archivo}, omitido.")
                continue

            # Guardar también la imagen en bytes
            with open(path, "rb") as f:
                imagen_bytes = f.read()

            lote.append({
                "id": id_foto,
                "encoding": encodings[0],
                "imagen_bytes": imagen_bytes
            })
            count += 1

            # Guardar lote cuando llegue al límite
            if count % LOTE_SIZE == 0:
                pkl_name = PROCESO + f"_lote_{lote_idx}.pkl"
                with open(os.path.join(OUTPUT_FOLDER, pkl_name), "wb") as f:
                    pickle.dump(lote, f)
                print(f"Guardado {pkl_name} con {len(lote)} registros")
                lote, lote_idx = [], lote_idx + 1

        except Exception as e:
            print(f"Error con {archivo}: {e}")

    # Guardar el último lote si quedó incompleto
    if lote:
        pkl_name = f"lote_{lote_idx}.pkl"
        with open(os.path.join(OUTPUT_FOLDER, pkl_name), "wb") as f:
            pickle.dump(lote, f)
        print(f"Guardado {pkl_name} con {len(lote)} registros (último lote)")

if __name__ == "__main__":
    generar_pkls_por_lotes()