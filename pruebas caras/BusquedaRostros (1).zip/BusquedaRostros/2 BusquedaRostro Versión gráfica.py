import sys, os, io, pickle
import face_recognition, cv2, numpy as np
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QPushButton, QFileDialog,
                             QVBoxLayout, QHBoxLayout, QTextEdit, QProgressBar, QListWidget, QListWidgetItem)
from PyQt5.QtGui import QPixmap, QColor, QImage
from PyQt5.QtCore import Qt

# ===============================
#  LoteManager
# ===============================
class LoteManager:
    def __init__(self, folder="encodings_pkl"):
        self.folder = folder
        self.rostros = []
        self.nombres = []
        self.index_mapa = []  # (archivo, idx dentro del lote)
        self.archivos = sorted([f for f in os.listdir(folder) if f.endswith(".pkl")])
        self.cache = {}

        self._cargar_encodings()

    def _cargar_encodings(self):
        for archivo in self.archivos:
            path = os.path.join(self.folder, archivo)
            with open(path, "rb") as f:
                lote = pickle.load(f)
                for idx, item in enumerate(lote):
                    self.rostros.append(item["encoding"])
                    self.nombres.append(f"ID_{item['id']}")
                    self.index_mapa.append((archivo, idx))
        print(f"Cargados {len(self.rostros)} encodings en memoria.")

    def obtener_imagen(self, indice):
        archivo, idx = self.index_mapa[indice]
        if archivo not in self.cache:
            path = os.path.join(self.folder, archivo)
            with open(path, "rb") as f:
                self.cache[archivo] = pickle.load(f)
        imagen_bytes = self.cache[archivo][idx]["imagen_bytes"]
        return face_recognition.load_image_file(io.BytesIO(imagen_bytes))


# ===============================
#  Interfaz FaceMatcher
# ===============================
class FaceMatcher(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Buscador Facial IPN - PyQt")
        self.setGeometry(100, 100, 1000, 700)

        self.lotes = LoteManager(folder="encodings_pkl")
        self.catalogo_rostros = self.lotes.rostros
        self.nombres = self.lotes.nombres

        self.init_ui()

    def init_ui(self):
        self.label_imagen = QLabel("Imagen de referencia")
        self.label_imagen.setFixedSize(250, 250)
        self.label_imagen.setStyleSheet("border: 1px solid black")
        self.label_imagen.setAlignment(Qt.AlignCenter)

        self.boton_seleccionar = QPushButton("Seleccionar Imagen")
        self.boton_seleccionar.clicked.connect(self.seleccionar_imagen)

        self.label_coincidencia = QLabel("Coincidencia seleccionada")
        self.label_coincidencia.setFixedSize(250, 250)
        self.label_coincidencia.setStyleSheet("border: 1px solid gray")
        self.label_coincidencia.setAlignment(Qt.AlignCenter)

        self.lista_resultados = QListWidget()
        self.lista_resultados.itemClicked.connect(self.mostrar_coincidencia)

        self.barra_progreso = QProgressBar()
        self.barra_progreso.setValue(0)

        self.log_texto = QTextEdit()
        self.log_texto.setReadOnly(True)
        self.log_texto.setFixedHeight(150)

        layout_izq = QVBoxLayout()
        layout_izq.addWidget(self.boton_seleccionar)
        layout_izq.addWidget(self.label_imagen)
        layout_izq.addWidget(self.label_coincidencia)

        layout_der = QVBoxLayout()
        layout_der.addWidget(self.lista_resultados)
        layout_der.addWidget(self.barra_progreso)
        layout_der.addWidget(self.log_texto)

        layout_main = QHBoxLayout()
        layout_main.addLayout(layout_izq)
        layout_main.addLayout(layout_der)

        self.setLayout(layout_main)
        self.log_texto.append("Sistema listo. Catálogo de encodings cargado.")

    def seleccionar_imagen(self):
        path, _ = QFileDialog.getOpenFileName(self, "Seleccionar Imagen", "", "Imágenes (*.png *.jpg *.jpeg)")
        if path:
            self.analizar_imagen(path)

    def analizar_imagen(self, path):
        self.lista_resultados.clear()
        self.barra_progreso.setValue(0)

        imagen_ref = face_recognition.load_image_file(path)
        encoding_ref = face_recognition.face_encodings(imagen_ref)

        if not encoding_ref:
            self.log_texto.append("⚠ No se detectó ningún rostro en la imagen seleccionada.")
            return

        self.mostrar_imagen(imagen_ref, self.label_imagen)

        encoding_ref = encoding_ref[0]
        distancias = face_recognition.face_distance(self.catalogo_rostros, encoding_ref)
        orden = np.argsort(distancias)

        self.orden_indices = orden[:30]  # Top 20 coincidencias
        total = len(self.orden_indices)

        for i, idx in enumerate(self.orden_indices):
            distancia = distancias[idx]
            nombre = self.nombres[idx]
            mensaje = f"Coincidencia #{i+1}: {nombre} - Distancia: {distancia:.4f}"
            color = QColor("green") if distancia < 0.45 else QColor("orange") if distancia < 0.6 else QColor("red")

            item = QListWidgetItem(mensaje)
            item.setForeground(color)
            self.lista_resultados.addItem(item)
            self.log_texto.append(mensaje)
            self.barra_progreso.setValue(int((i+1)/total * 100))

    def mostrar_imagen(self, img, label):
        bgr = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        q_image = QImage(rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(q_image)
        label.setPixmap(pixmap.scaled(label.size(), Qt.KeepAspectRatio))

    def mostrar_coincidencia(self, item):
        if item is not None:
            idx = self.lista_resultados.row(item)
            if idx < len(self.orden_indices):
                img = self.lotes.obtener_imagen(self.orden_indices[idx])
                self.mostrar_imagen(img, self.label_coincidencia)


# ===============================
#  Main
# ===============================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = FaceMatcher()
    ventana.show()
    sys.exit(app.exec_())